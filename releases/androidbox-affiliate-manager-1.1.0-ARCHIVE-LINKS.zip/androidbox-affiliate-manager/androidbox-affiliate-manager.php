<?php
/**
 * Plugin Name: AndroidBox.cz Affiliate Manager
 * Description: Bezpečná administrace skutečných affiliate/nákupních URL pro produkty AndroidBox.cz. Nahrazuje starý HTML link importer.
 * Version: 1.1.0
 * Author: AndroidBox.cz
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const AB_AFF_VER = '1.1.0';
const AB_AFF_META_KEYS = array( 'androidbox', 'heureka', 'aliexpress', 'geekbuying', 'archive' );

/**
 * Archived 1url.cz links supplied by the site owner.
 * They are stored verbatim; destinations are never guessed or rewritten.
 */
const AB_AFF_ARCHIVE_LINKS = array(
    'x96x40'=>'https://1url.cz/@x96x40','X96CZ1'=>'https://1url.cz/@X96CZ1','km6deeluxe'=>'https://1url.cz/@km6deeluxe',
    'mecoolnetflix'=>'https://1url.cz/@mecoolnetflix','Mecoolkm2plus'=>'https://1url.cz/@Mecoolkm2plus',
    'mitvstick2'=>'https://1url.cz/@mitvstick2','mitvstick432'=>'https://1url.cz/@mitvstick432','mibox234'=>'https://1url.cz/@mibox234',
    'mecoolkm7'=>'https://1url.cz/@mecoolkm7','mecoolKD1'=>'https://1url.cz/@mecoolKD1','Realmestick'=>'https://1url.cz/@Realmestick',
    'mecoolkm6deluxxe'=>'https://1url.cz/@mecoolkm6deluxxe','mecooLKT1'=>'https://1url.cz/@mecooLKT1','redukceXiaomi'=>'https://1url.cz/@redukceXiaomi',
    'X96plusultra'=>'https://1url.cz/@X96plusultra','VontarX3_9dni'=>'https://1url.cz/@VontarX3_9dni','VontarX4'=>'https://1url.cz/@VontarX4',
    'X96X4'=>'https://1url.cz/@X96X4','X96X4Gbit'=>'https://1url.cz/@X96X4Gbit','X96x4gbit'=>'https://1url.cz/@X96x4gbit',
    'GigabitUSBA'=>'https://1url.cz/@GigabitUSBA','Kd3mecool'=>'https://1url.cz/@Kd3mecool','Kd2mecool'=>'https://1url.cz/@Kd2mecool',
    'Xiaomitvsrick'=>'https://1url.cz/@Xiaomitvsrick','RealmeTVstick'=>'https://1url.cz/@RealmeTVstick','dzblT'=>'https://1url.cz/dzblT',
    'homaticsboxR'=>'https://1url.cz/@homaticsboxR','TanixTX3Gbit'=>'https://1url.cz/@TanixTX3Gbit'
);
function ab_aff_archive_seed_map() {
    return array(
        'X96 X4'=>array('x96x40','X96X4','X96X4Gbit','X96x4gbit'),'X96 Max+'=>array('X96CZ1','dzblT'),
        'X96 Max Ultra'=>array('X96plusultra'),'Vontar X3'=>array('VontarX3_9dni'),'Vontar X4'=>array('VontarX4'),
        'Homatics Box R Plus'=>array('homaticsboxR'),'Tanix TX3'=>array('TanixTX3Gbit'),
        'Mecool KM2+ Deluxe'=>array('km6deeluxe','mecoolkm6deluxxe'),'Mecool KM2+'=>array('Mecoolkm2plus'),
        'Mecool KM7'=>array('mecoolkm7'),'Mecool KD1'=>array('mecoolKD1'),'Mecool KT1'=>array('mecooLKT1'),
        'Mi TV Stick'=>array('mitvstick2'),'Mi TV Stick 4K'=>array('mitvstick432'),'Mi Box'=>array('mibox234'),
        'Realme TV Stick'=>array('Realmestick','RealmeTVstick'),'Xiaomi'=>array('redukceXiaomi','Xiaomitvsrick')
    );
}
add_action('admin_init',function(){
    if(!is_admin()||!ab_aff_can_manage()||get_option('ab_aff_archive_seeded_v1_1')) return;
    $count=0;
    foreach(ab_aff_archive_seed_map() as $title=>$keys){
        $posts=get_posts(array('post_type'=>'androidbox_product','post_status'=>array('publish','draft','pending','private'),'posts_per_page'=>1,'title'=>$title));
        if(empty($posts)) continue;
        $id=$posts[0]->ID; $urls=array();
        foreach($keys as $key) if(isset(AB_AFF_ARCHIVE_LINKS[$key])) $urls[]=AB_AFF_ARCHIVE_LINKS[$key];
        if(empty($urls)) continue;
        if(''===get_post_meta($id,'androidbox',true)) update_post_meta($id,'androidbox',$urls[0]);
        update_post_meta($id,'archive',implode("\n",$urls)); $count++;
    }
    update_option('ab_aff_archive_seeded_v1_1',array('time'=>current_time('mysql'),'products'=>$count),false);
});

function ab_aff_can_manage() {
    return current_user_can( 'manage_options' );
}

function ab_aff_sanitize_url( $value ) {
    $value = trim( (string) $value );
    if ( '' === $value ) return '';

    $url = esc_url_raw( $value );
    if ( '' === $url ) return '';

    $parts = wp_parse_url( $url );
    if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
        return '';
    }

    return $url;
}

function ab_aff_product_fields( $post_id ) {
    $fields = array();
    foreach ( AB_AFF_META_KEYS as $key ) {
        $fields[ $key ] = (string) get_post_meta( $post_id, $key, true );
    }
    return $fields;
}

function ab_aff_field_label( $key ) {
    $labels = array(
        'androidbox' => 'AndroidBox.cz',
        'heureka'    => 'Heureka',
        'aliexpress' => 'AliExpress',
        'geekbuying' => 'Geekbuying',
        'archive'    => 'Archiv původních odkazů',
    );
    return isset( $labels[ $key ] ) ? $labels[ $key ] : $key;
}

add_action( 'admin_menu', function () {
    if ( ! ab_aff_can_manage() ) return;

    $has_site_manager = false;
    foreach ( (array) $GLOBALS['menu'] as $menu_item ) {
        if ( isset( $menu_item[2] ) && 'androidbox-site-manager' === $menu_item[2] ) {
            $has_site_manager = true;
            break;
        }
    }

    if ( $has_site_manager ) {
        add_submenu_page(
            'androidbox-site-manager',
            'Affiliate odkazy',
            'Affiliate odkazy',
            'manage_options',
            'androidbox-affiliate-manager',
            'ab_aff_admin_page'
        );
    } else {
        add_menu_page(
            'Affiliate odkazy',
            'Affiliate odkazy',
            'manage_options',
            'androidbox-affiliate-manager',
            'ab_aff_admin_page',
            'dashicons-admin-links',
            4
        );
    }
}, 30 );

add_action( 'add_meta_boxes', function () {
    add_meta_box(
        'androidbox_affiliate_links',
        'AndroidBox.cz – nákupní / affiliate odkazy',
        'ab_aff_meta_box',
        'androidbox_product',
        'normal',
        'default'
    );
} );

function ab_aff_meta_box( $post ) {
    if ( ! current_user_can( 'edit_post', $post->ID ) ) return;

    wp_nonce_field( 'ab_aff_save_product_' . $post->ID, 'ab_aff_nonce' );
    $fields = ab_aff_product_fields( $post->ID );
    echo '<p>Vkládej pouze skutečné URL. Nic se automaticky nevymýšlí ani negeneruje.</p>';

    foreach ( AB_AFF_META_KEYS as $key ) {
        if ( 'archive' === $key ) {
            printf('<p><label for="ab-aff-archive"><strong>%s</strong></label><br><textarea id="ab-aff-archive" class="widefat" rows="5" name="ab_aff[archive]" placeholder="1 odkaz na řádek">%s</textarea></p>',
                esc_html(ab_aff_field_label($key)), esc_textarea($fields[$key]));
        } else {
            printf(
                '<p><label for="ab-aff-%1$s"><strong>%2$s</strong></label><br><input id="ab-aff-%1$s" class="widefat" type="url" inputmode="url" name="ab_aff[%1$s]" value="%3$s" placeholder="https://..."></p>',
                esc_attr( $key ), esc_html( ab_aff_field_label( $key ) ), esc_attr( $fields[ $key ] )
            );
        }
    }
}

add_action( 'save_post_androidbox_product', function ( $post_id ) {
    if ( ! isset( $_POST['ab_aff_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ab_aff_nonce'] ) ), 'ab_aff_save_product_' . $post_id ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( wp_is_post_revision( $post_id ) ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $input = isset( $_POST['ab_aff'] ) && is_array( $_POST['ab_aff'] ) ? wp_unslash( $_POST['ab_aff'] ) : array();

    foreach ( AB_AFF_META_KEYS as $key ) {
        $value = isset( $input[ $key ] ) ? ( 'archive' === $key ? implode("\n", array_filter(array_map('ab_aff_sanitize_url', preg_split('/\R+/', (string)$input[$key])))) : ab_aff_sanitize_url( $input[ $key ] ) ) : '';
        if ( '' === $value ) {
            delete_post_meta( $post_id, $key );
        } else {
            update_post_meta( $post_id, $key, $value );
        }
    }
} );

function ab_aff_admin_page() {
    if ( ! ab_aff_can_manage() ) {
        wp_die( esc_html__( 'Nemáte oprávnění.', 'androidbox' ) );
    }

    $products = get_posts( array(
        'post_type'      => 'androidbox_product',
        'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ) );

    echo '<div class="wrap"><h1>AndroidBox.cz – Affiliate odkazy</h1>';
    echo '<p>Správa skutečných URL přímo ve WordPressu. Žádný veřejný importer, žádné automatické generování odkazů. Dodané archivní 1url.cz odkazy jsou zachovány beze změny.</p>';

    if ( isset( $_POST['ab_aff_bulk_save'] ) ) {
        check_admin_referer( 'ab_aff_bulk_save_action', 'ab_aff_bulk_nonce' );

        foreach ( $products as $product ) {
            if ( ! current_user_can( 'edit_post', $product->ID ) ) continue;

            $row = isset( $_POST['ab_aff_bulk'][ $product->ID ] ) && is_array( $_POST['ab_aff_bulk'][ $product->ID ] )
                ? wp_unslash( $_POST['ab_aff_bulk'][ $product->ID ] )
                : array();

            foreach ( AB_AFF_META_KEYS as $key ) {
                $value = isset( $row[ $key ] ) ? ( 'archive' === $key ? implode("\n", array_filter(array_map('ab_aff_sanitize_url', preg_split('/\R+/', (string)$row[$key])))) : ab_aff_sanitize_url( $row[ $key ] ) ) : '';
                if ( '' === $value ) {
                    delete_post_meta( $product->ID, $key );
                } else {
                    update_post_meta( $product->ID, $key, $value );
                }
            }
        }

        echo '<div class="notice notice-success is-dismissible"><p>Affiliate odkazy byly uloženy.</p></div>';
    }

    if ( empty( $products ) ) {
        echo '<div class="notice notice-info"><p>Zatím nejsou vytvořené žádné produkty typu <code>androidbox_product</code>.</p></div></div>';
        return;
    }

    echo '<form method="post">';
    wp_nonce_field( 'ab_aff_bulk_save_action', 'ab_aff_bulk_nonce' );
    echo '<table class="widefat striped"><thead><tr><th>Produkt</th>';

    foreach ( AB_AFF_META_KEYS as $key ) {
        echo '<th>' . esc_html( ab_aff_field_label( $key ) ) . '</th>';
    }

    echo '</tr></thead><tbody>';

    foreach ( $products as $product ) {
        $fields = ab_aff_product_fields( $product->ID );

        echo '<tr><td><strong>' . esc_html( get_the_title( $product->ID ) ) . '</strong><br><a href="' . esc_url( get_edit_post_link( $product->ID ) ) . '">upravit produkt</a></td>';

        foreach ( AB_AFF_META_KEYS as $key ) {
            if ( 'archive' === $key ) {
                printf('<td><textarea style="min-width:220px" rows="3" name="ab_aff_bulk[%1$d][archive]" placeholder="1 odkaz na řádek">%2$s</textarea></td>',
                    (int)$product->ID, esc_textarea($fields['archive']));
            } else {
                printf('<td><input class="regular-text" style="min-width:220px" type="url" inputmode="url" name="ab_aff_bulk[%1$d][%2$s]" value="%3$s" placeholder="https://..."></td>',
                    (int)$product->ID, esc_attr($key), esc_attr($fields[$key]));
            }
        }

        echo '</tr>';
    }

    echo '</tbody></table><p class="submit"><button type="submit" class="button button-primary" name="ab_aff_bulk_save" value="1">Uložit všechny odkazy</button></p></form>';
    echo '<p><strong>Bezpečnost:</strong> stránka je pouze pro administrátory, používá WordPress nonce, kontrolu oprávnění a validaci HTTP/HTTPS URL.</p></div>';
}
